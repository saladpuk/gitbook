﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using Newtonsoft.Json;
using RestSharp;

namespace saladpuk_handwritten_text
{
	class Program
	{
		// static string SubscriptionKey = "FACE_SUBSCRIPTION_KEY";
		// static string Endpoint = "FACE_ENDPOINT";

		static string SubscriptionKey = "be6b8fd9fe2a48b5a050f1016b571170";
		static string Endpoint = "https://southeastasia.api.cognitive.microsoft.com/";

		static void Main(string[] args)
		{
			var client = new RestClient(Endpoint);

			// เรียกใช้ Batch Read File
			Console.WriteLine("Running Batch read file.");
			var operationlocation = string.Empty;
			var batchReadFileRequest = CreateRestRequest("vision/v2.1/read/core/asyncBatchAnalyze", new
			{
				url = "https://jooinn.com/images/handwritten-text-1.jpg"
			});
			var batchReadFileResult = client.Execute(batchReadFileRequest, Method.POST);
			if (batchReadFileResult.StatusCode == HttpStatusCode.Accepted)
			{
				var operationlocationUrl = batchReadFileResult.Headers.FirstOrDefault(it => it.Name == "Operation-Location").Value.ToString();
				operationlocation = Path.GetFileName(operationlocationUrl);
				Console.WriteLine($"-> Done. Operation-Location: {operationlocation}");
			}
			else
			{
				Console.WriteLine($"Error: {batchReadFileResult.Content}");
				return;
			}

			// เรียกใช้ Get Read Operation Result
			Console.WriteLine("Running Get read operation result.");
			while (true)
			{
				var getReadOperationRequest = CreateRestRequest($"vision/v2.1/read/operations/{operationlocation}", null);
				var getReadOperationResult = client.Execute(getReadOperationRequest, Method.GET);
				if (getReadOperationResult.StatusCode == HttpStatusCode.OK)
				{
					const string Succeeded = "Succeeded";
					var result = JsonConvert.DeserializeObject<ReadOperationResultInfo>(getReadOperationResult.Content);
					if (result.Status == Succeeded)
					{
						var linesQry = result.RecognitionResults.SelectMany(it => it.Lines).Select(it => it.Text);
						var message = string.Join(Environment.NewLine, linesQry);
						Console.WriteLine($"-> Done. the message is{Environment.NewLine}{message}");
						break;
					}
				}
				else
				{
					Console.WriteLine($"Incomplete or error, retrying in 1 second.");
					System.Threading.Thread.Sleep(1000);
				}
			}
		}

		static RestRequest CreateRestRequest(string resource, object requestBody)
		{
			var request = new RestRequest(resource);
			request.AddHeader("ocp-apim-subscription-key", SubscriptionKey);
			if (requestBody != null)
			{
				request.AddHeader("content-type", "application/json");
				request.AddJsonBody(requestBody);
			}
			return request;
		}

		class ReadOperationResultInfo
		{
			public string Status { get; set; }
			public IEnumerable<RecognitionInfo> RecognitionResults { get; set; }
		}
		class RecognitionInfo
		{
			public IEnumerable<LineInfo> Lines { get; set; }
		}
		class LineInfo
		{
			public string Text { get; set; }
		}
	}
}
