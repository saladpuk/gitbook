﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;

namespace saladpuk_demo
{
	class Program
	{
		static string Endpoint = "https://southeastasia.api.cognitive.microsoft.com/";
		static string SubscriptionKey = "ENTER_YOUR_SUBSCRIPTION_KEY_HERE";

		static void Main(string[] args)
		{
			var client = new RestClient(Endpoint);

			var returnFaceAttributes = "returnFaceAttributes=age,gender,glasses,emotion,makeup,accessories";
			var faceDetectRequest = CreateRestRequest($"face/v1.0/detect?returnFaceId=true&{returnFaceAttributes}", new
			{
				url = "https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-Lm0_idNbY6k1lwp6hm4%2F-LoCfku1h93nvIQvqkaR%2F-LoCglDFUW0smoSUxSMs%2Fimage.png?alt=media&token=cd35a07f-4f22-4a00-b8ac-0274c4fc7791"
			});
			var faceDetectResult = client.Execute(faceDetectRequest, Method.POST);
			if (faceDetectResult.StatusCode == HttpStatusCode.OK)
			{
				var faces = JArray.Parse(faceDetectResult.Content);
				foreach (var item in faces)
				{
					Console.WriteLine(item);
				}
			}
			else
			{
				Console.WriteLine(faceDetectResult.Content);
			}
		}

		static RestRequest CreateRestRequest(string resource, object requestBody)
		{
			var request = new RestRequest(resource);
			request.AddHeader("content-type", "application/json");
			request.AddHeader("ocp-apim-subscription-key", SubscriptionKey);
			if (requestBody != null)
			{
				request.AddJsonBody(requestBody);
			}
			return request;
		}
	}
}