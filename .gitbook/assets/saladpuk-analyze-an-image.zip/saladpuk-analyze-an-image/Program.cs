﻿using System;
using System.Linq;
using System.Net;
using Newtonsoft.Json.Linq;
using RestSharp;

namespace saladpuk_analyze_an_image
{
	class Program
	{
		static string SubscriptionKey = "729c47c3f04346dd904cac8ef8181412";
		static string Endpoint = "https://southeastasia.api.cognitive.microsoft.com/";

		static void Main(string[] args)
		{
			var client = new RestClient(Endpoint);

			var analyzieImageRequest = CreateRestRequest("vision/v2.1/analyze?visualFeatures=Description&language=en", new
			{
				url = "https://www.natures-images.co.uk/wp-content/uploads/2014/02/Brown-bear-2011-10-Paul-Hobson.jpg"
			});
			var analyzieImageResult = client.Execute(analyzieImageRequest, Method.POST);
			if (analyzieImageResult.StatusCode == HttpStatusCode.OK)
			{
				var captionsText = JObject.Parse(analyzieImageResult.Content)["description"]["captions"].ToString();
				var captions = JArray.Parse(captionsText).Select(it => it["text"]?.ToString()).Where(it => !string.IsNullOrWhiteSpace(it));
				foreach (var item in captions)
				{
					Console.WriteLine(item);
				}
			}
			else
			{
				System.Console.WriteLine($"Error: {analyzieImageResult.Content}");
			}
		}

		static RestRequest CreateRestRequest(string resource, object requestBody)
		{
			var request = new RestRequest(resource);
			request.AddHeader("ocp-apim-subscription-key", SubscriptionKey);
			if (requestBody != null)
			{
				request.AddHeader("content-type", "application/json");
				request.AddJsonBody(requestBody);
			}
			return request;
		}
	}
}