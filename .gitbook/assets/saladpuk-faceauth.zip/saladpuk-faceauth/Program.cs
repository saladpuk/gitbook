﻿using System;
using System.Linq;
using System.Net;
using Newtonsoft.Json.Linq;
using RestSharp;

namespace saladpuk_faceauth
{
	class Program
	{
		static string SubscriptionKey = "729c47c3f04346dd904cac8ef8181412";
		static string Endpoint = "https://saladpuk-face.cognitiveservices.azure.com/face/v1.0";

		static void Main(string[] args)
		{
			var client = new RestClient(Endpoint);

			// สร้าง PersonGroup
			Console.WriteLine($"Create a PersonGroup.");
			var personGroupId = Guid.NewGuid().ToString().ToLower();
			var createPersonGroupReq = CreateRestRequest($"persongroups/{personGroupId}", new
			{
				name = "Prime Minister",
			});
			var createPersonGroupResult = client.Execute(createPersonGroupReq, Method.PUT);
			if (createPersonGroupResult.StatusCode == HttpStatusCode.OK)
			{
				Console.WriteLine($"-> Done. PersonGroup Id: {personGroupId}");
			}
			else
			{
				Console.WriteLine($"Error: {createPersonGroupResult.Content}");
				return;
			}

			// สร้าง Person
			var personId = string.Empty;
			Console.WriteLine($"Create a Person");
			var createPersonGroupPersonRequest = CreateRestRequest($"persongroups/{personGroupId}/persons", new
			{
				name = "Prayut Chan O Char",
			});
			var createPersonGroupPersonResult = client.Execute(createPersonGroupPersonRequest, Method.POST);
			if (createPersonGroupPersonResult.StatusCode == HttpStatusCode.OK)
			{
				personId = JObject.Parse(createPersonGroupPersonResult.Content)["personId"].ToString();
				Console.WriteLine($"-> Done. {createPersonGroupPersonResult.Content}");
			}
			else
			{
				Console.WriteLine($"Error: {createPersonGroupPersonResult.Content}");
				return;
			}

			// อัพโหลดรูปคนที่จะใช้ในการยืนยันตัวตน
			Console.WriteLine("Uploading your images.");
			var personImageUrls = new[]
			{
				@"https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Prayut_Chan-o-cha_%28cropped%29_2016.jpg/220px-Prayut_Chan-o-cha_%28cropped%29_2016.jpg",
				@"https://www.straitstimes.com/sites/default/files/styles/article_pictrure_780x520_/public/articles/2018/09/24/yq-prayutchan-24092018.jpg",
				@"http://www.asianews.eu/sites/default/files/public/uploads/field_s_photos/prayut_chan-o-cha.jpg",
				@"https://i.pinimg.com/originals/f1/ea/c8/f1eac8e52461ac10c61089a3ffe2c016.jpg",
				@"https://pbs.twimg.com/profile_images/1084270206938099712/qR9TdPQD_400x400.jpg",
				@"https://news.mthai.com/app/uploads/2017/08/19-08-17.jpg",
				@"https://www.newsringside.com/wp-content/uploads/2018/01/4DQpjUtzLUwmJZZCzaRpSFJqsuBh3xw4QRClWyUWGED4.jpg",
				@"https://www.sunnewsonline.com/wp-content/uploads/2018/10/Thai-PM.jpg",
				@"https://images.financialexpress.com/2017/09/download-4-14.jpg",
				@"http://www.thaiembassy.org/hanoi/contents/images/text_editor/images/PM1.jpg",
			};
			var uploadedCounter = 0;
			foreach (var imgUrl in personImageUrls)
			{
				var addFaceRequest = CreateRestRequest($"persongroups/{personGroupId}/persons/{personId}/persistedFaces", new
				{
					url = imgUrl,
				});
				var addFaceResult = client.Execute(addFaceRequest, Method.POST);
				if (addFaceResult.StatusCode == HttpStatusCode.OK)
				{
					Console.WriteLine($"-> an image has been uploaded. {++uploadedCounter}/{personImageUrls.Count()}");
				}
				else
				{
					Console.WriteLine($"Error: {addFaceResult.Content}");
				}
			}
			Console.WriteLine("-> All Done.");

			// สั่งให้ AI เรียนรู้หน้าตาของ Person (Train Model)
			Console.WriteLine("Training your model.");
			var trainModelRequest = CreateRestRequest($"persongroups/{personGroupId}/train", null);
			var trainModelResult = client.Execute(trainModelRequest, Method.POST);
			if (trainModelResult.StatusCode == HttpStatusCode.Accepted)
			{
				Console.WriteLine($"-> Done.");
			}
			else
			{
				Console.WriteLine($"Error: {trainModelResult.Content}");
			}

			// ทดสอบว่ารูปคนอื่นสามารถยืนยันตัวตนได้หรือไม่
			var thaksinResult = IdentifyAnImage(client, personGroupId, personId, "https://www.prachachat.net/wp-content/uploads/2017/09/13814050451381405054l.jpg");
			Console.WriteLine($"The result from using Thaksin's image is: {thaksinResult}");

			// ทดสอบว่ารูปที่ถูกต้องสามารถยืนยันตัวตนได้หรือไม่
			var prayutResult = IdentifyAnImage(client, personGroupId, personId, "https://www.thairath.co.th/media/NjpUs24nCQKx5e1EaLUGBbZOOxIXurh1BCeiRWkxZwq.jpg");
			Console.WriteLine($"The result from using Prayut's image is: {prayutResult}");
		}

		static RestRequest CreateRestRequest(string resource, object requestBody)
		{
			var request = new RestRequest(resource);
			request.AddHeader("ocp-apim-subscription-key", SubscriptionKey);
			if (requestBody != null)
			{
				request.AddHeader("content-type", "application/json");
				request.AddJsonBody(requestBody);
			}
			return request;
		}

		static bool IdentifyAnImage(RestClient client, string personGroupId, string personId, string imagePath)
		{
			var detectFaceRequest = CreateRestRequest("detect?returnFaceId=true", new
			{
				url = imagePath,
			});
			var detectFaceResult = client.Execute(detectFaceRequest, Method.POST);
			if (detectFaceResult.StatusCode == HttpStatusCode.OK)
			{
				var faceId = JArray.Parse(detectFaceResult.Content).First["faceId"].ToString();
				var verifyRequest = CreateRestRequest("verify", new
				{
					faceId = faceId,
					personId = personId,
					personGroupId = personGroupId,
				});
				var verifyResult = client.Execute(verifyRequest, Method.POST);
				if (verifyResult.StatusCode == HttpStatusCode.OK)
				{
					var confidenceText = JObject.Parse(verifyResult.Content)["confidence"].ToString();
					var confidence = double.Parse(confidenceText);
					return confidence >= 0.75;
				}
				else
				{
					Console.WriteLine($"Error: {verifyResult.Content}");
					return false;
				}
			}
			else
			{
				Console.WriteLine($"Error: {detectFaceResult.Content}");
				return false;
			}
		}
	}
}