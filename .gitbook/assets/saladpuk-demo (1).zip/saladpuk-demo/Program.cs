﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using Newtonsoft.Json;
using RestSharp;

namespace saladpuk_demo
{
	class Program
	{
		static string Endpoint = "ENTER_YOUR_ENDPOINT_HERE";
		static string SubscriptionKey = "ENTER_YOUR_SUBSCRIPTION_KEY_HERE";

		static void Main(string[] args)
		{
			var client = new RestClient(Endpoint);

			// โค้ดในตัวอย่างอื่นๆจะเอามาเขียนต่อใส่ตรงนี้
		}

		static RestRequest CreateRestRequest(string resource, object requestBody)
		{
			var request = new RestRequest(resource);
			request.AddHeader("content-type", "application/json");
			request.AddHeader("ocp-apim-subscription-key", SubscriptionKey);
			if (requestBody != null)
			{
				request.AddJsonBody(requestBody);
			}
			return request;
		}
	}
}