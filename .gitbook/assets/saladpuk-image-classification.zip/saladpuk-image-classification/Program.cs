﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using Microsoft.Azure.CognitiveServices.Vision.CustomVision.Prediction;
using Microsoft.Azure.CognitiveServices.Vision.CustomVision.Training;
using Microsoft.Azure.CognitiveServices.Vision.CustomVision.Training.Models;

namespace saladpuk_image_classification
{
	class Program
	{
		const string Endpoint = "https://southeastasia.api.cognitive.microsoft.com/";
		const string TrainingKey = "9307b0e4690f43219a136680e5b59740";
		const string PredictionKey = "f8b0f6ce2cda4b7d8cef892b3f3de468";
		const string PredictionResourceId = "/subscriptions/c91771fb-def2-45f8-9400-673d59a95640/resourceGroups/saladpuk-demo/providers/Microsoft.CognitiveServices/accounts/saladpuk-prediction";

		static void Main(string[] args)
		{
var trainingClient = new CustomVisionTrainingClient()
{
	ApiKey = TrainingKey,
	Endpoint = Endpoint
};

Console.WriteLine("Creating new project:");
var project = trainingClient.CreateProject("Saladpuk demo");

Console.WriteLine("Uploading Prayut images.");
var prayutTag = trainingClient.CreateTag(project.Id, "Prayut");
var prayutImages = Directory.GetFiles(Path.Combine("Images", "Prayut"));
var prayutFiles = prayutImages.Select(img => new ImageFileCreateEntry(Path.GetFileName(img), File.ReadAllBytes(img))).ToList();
trainingClient.CreateImagesFromFiles(project.Id, new ImageFileCreateBatch(prayutFiles, new List<Guid>() { prayutTag.Id }));
Console.WriteLine("-> Done.");

Console.WriteLine("Uploading Thaksin images.");
var thaksinTag = trainingClient.CreateTag(project.Id, "Thaksin");
var thaksinImages = Directory.GetFiles(Path.Combine("Images", "Thaksin"));
var thaksinFiles = thaksinImages.Select(img => new ImageFileCreateEntry(Path.GetFileName(img), File.ReadAllBytes(img))).ToList();
trainingClient.CreateImagesFromFiles(project.Id, new ImageFileCreateBatch(thaksinFiles, new List<Guid>() { thaksinTag.Id }));
Console.WriteLine("-> Done.");


Console.WriteLine("Training.");
var iteration = trainingClient.TrainProject(project.Id);
while (iteration.Status == "Training")
{
	Thread.Sleep(1000);
	iteration = trainingClient.GetIteration(project.Id, iteration.Id);
}
Console.WriteLine("-> Done.");

Console.WriteLine("Publishing.");
var publishedName = "GuessWho";
trainingClient.PublishIteration(project.Id, iteration.Id, publishedName, PredictionResourceId);
Console.WriteLine("-> Done.");


Console.WriteLine("Making a prediction.");
var predictionClient = new CustomVisionPredictionClient()
{
	ApiKey = PredictionKey,
	Endpoint = Endpoint
};
var testImage = new MemoryStream(File.ReadAllBytes(Path.Combine("Images", @"Test\Test.jpg")));
var result = predictionClient.ClassifyImage(project.Id, publishedName, testImage);
foreach (var prediction in result.Predictions)
{
	Console.WriteLine($"-> {prediction.TagName}: {prediction.Probability:P1}");
}
Console.WriteLine("-> Done.");

			// Console.WriteLine("Deleting your project.");
			// trainingClient.UnpublishIteration(project.Id, iteration.Id);
			// trainingClient.DeleteIteration(project.Id, iteration.Id);
			// trainingClient.DeleteProject(project.Id);
			// Console.WriteLine("-> Done.");
		}
	}
}
